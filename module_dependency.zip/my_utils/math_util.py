def my_tripple(input):
    return input * input * input
